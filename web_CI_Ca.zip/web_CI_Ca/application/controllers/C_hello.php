<?php
class C_hello extends CI_Controller{
	function index(){
		?>
		<!doctype html>
		<html>
		<head>
			<title>Hello World!</title>
		</head>
		<body>
		<?php echo "Hello world!";?>
		</body>
		</html>
		<?php
	}
}
?>
