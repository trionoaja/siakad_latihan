<?php
class c_v_hello extends CI_Controller{
	function index(){
		$this->load->view("v_c_v_hello");
	}
}
?>
