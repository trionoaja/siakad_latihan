<html>
    <head>
        <title>Hello World</title>
        <style type="text/css">
            #container{
                margin: 10px;
                border: 1px solid #D0D0D0;
                background: #8A2BE2;
                height: 200px;
                width: 400px;
                -webkit-box-shadow: 0 0 8px #D0D0D0;
            }
            </style>
            </head>
            <body>
                <div id="container">
                    <?php echo $halo;?>
        </div>
        </body>
        </html>