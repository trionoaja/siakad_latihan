<html>
    <head>
        <title>Hello world</title>
</head>
<body>
    <?php echo $halo;?>
</body>
</html>